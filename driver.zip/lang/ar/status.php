<?php

use App\Enums\OrderStatus;

return [
    'order' => [
        OrderStatus::PENDING->value => "قيد التنفيذ",
        OrderStatus::IN_PROGRESS->value => "جاري التوصيل",
        OrderStatus::COMPLETE->value => "مكتمل",
        OrderStatus::CANCELLED->value => "ملغي",
    ],
];
