<?php

use App\Enums\OrderStatus;

return [
    'order' => [
        OrderStatus::PENDING->value => "Pending",
        OrderStatus::IN_PROGRESS->value => "In Progress",
        OrderStatus::COMPLETE->value => "Complete",
        OrderStatus::CANCELLED->value => "Cancelled",
    ],
];
