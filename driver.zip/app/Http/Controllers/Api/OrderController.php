<?php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use App\Http\Resources\OrderResource;
use App\Traits\response;


class OrderController extends Controller
{
    use response;

    public function index()
    {
        $orders = auth()->user()->orders()
            ->select([
                'id',
                'customer_id',
                'provider_id',
                'address_id',
                'branch_id',
                'subtotal',
                'delivery_fee',
                'total',
                'order_code',
                'note',
                'status'
            ])
            ->with([
                'customer:id,name,phone,second_phone',
                'address:id,address,bookmark,lat,long,city_id'=>[
                    'city:id,name'
                ],
                'branch:id,provider_id,name,address' => [
                    'provider:id,name,image'
                ]
            ])
            ->withCount('products')
            ->paginate();


        return $this->success(
            $orders,
            OrderResource::class
        );
    }
}
